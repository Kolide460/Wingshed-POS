// Wingshed — Menu screen + Item detail screen
const { useState: useStateA, useMemo: useMemoA, useEffect: useEffectA, useRef: useRefA } = React;

// ═══ Menu Screen ═════════════════════════════════════════════════════════
function MenuScreen({ cart, onOpenItem, onOpenCart, onOpenOrders, mode, setMode, density }) {
  const [cat, setCat] = useStateA('All');
  const [query, setQuery] = useStateA('');

  const items = useMemoA(() => {
    return MENU.filter(m => (cat === 'All' || m.cat === cat))
               .filter(m => !query || m.name.toLowerCase().includes(query.toLowerCase()));
  }, [cat, query]);

  const cartCount = cart.reduce((s, l) => s + l.qty, 0);
  const cartTotal = cart.reduce((s, l) => s + l.lineTotal, 0);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: wsT.bg }}>

      {/* Header */}
      <div style={{ paddingTop: TOP_INSET, padding: `${TOP_INSET}px 20px 0` }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Logo size={26}/>
            <span style={{ fontFamily: wsFont, fontWeight: 600, fontSize: 19, letterSpacing: '-0.025em', color: wsT.ink }}>wingshed</span>
          </div>
          <button onClick={onOpenOrders} style={{
            width: 38, height: 38, borderRadius: 999,
            border: `1px solid ${wsT.line}`, background: 'transparent',
            color: wsT.ink, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{Icon.receipt}</button>
        </div>

        {/* Mode toggle */}
        <ModeToggle mode={mode} setMode={setMode} />

        {/* Greeting */}
        <h1 style={{
          fontFamily: wsFont, fontSize: 28, fontWeight: 600,
          letterSpacing: '-0.035em', lineHeight: 1.1,
          margin: '22px 0 4px', color: wsT.ink,
        }}>
          What's your damage<br/>tonight?
        </h1>
        <div style={{
          fontFamily: wsFont, fontSize: 14, color: wsT.inkMuted,
          letterSpacing: '-0.01em', marginBottom: 16,
        }}>
          Kitchen open · ~12 min wait
        </div>

        {/* Search */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '11px 14px', borderRadius: 12,
          background: wsT.surface, border: `1px solid ${wsT.line}`,
          marginBottom: 14,
        }}>
          <span style={{ color: wsT.inkMuted, display: 'flex' }}>{Icon.search}</span>
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search the menu"
            style={{
              flex: 1, border: 'none', outline: 'none', background: 'transparent',
              fontFamily: wsFont, fontSize: 15, color: wsT.ink,
              letterSpacing: '-0.01em',
            }}
          />
        </div>
      </div>

      {/* Categories */}
      <div style={{
        display: 'flex', gap: 8, padding: '0 20px 4px',
        overflowX: 'auto', flexShrink: 0,
        scrollbarWidth: 'none', msOverflowStyle: 'none',
      }}>
        {CATEGORIES.map(c => (
          <Chip key={c} active={cat === c} onClick={() => setCat(c)}>{c}</Chip>
        ))}
      </div>

      {/* List */}
      <div style={{
        flex: 1, overflow: 'auto', padding: '14px 20px',
        paddingBottom: cartCount > 0 ? 110 : 40,
      }}>
        {items.length === 0 && (
          <div style={{
            textAlign: 'center', padding: '60px 0',
            fontFamily: wsFont, color: wsT.inkMuted, fontSize: 14,
          }}>Nothing matches "{query}"</div>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', gap: density === 'compact' ? 4 : 8 }}>
          {items.map(item => (
            <MenuRow key={item.id} item={item} onClick={() => onOpenItem(item)} compact={density === 'compact'}/>
          ))}
        </div>

        <div style={{
          marginTop: 32, paddingTop: 20, borderTop: `1px solid ${wsT.line}`,
          fontFamily: wsFont, fontSize: 11, color: wsT.inkMuted,
          letterSpacing: '0.04em', textTransform: 'uppercase',
        }}>
          Wingshed · est. 2021 · made in a hurry, eaten faster
        </div>
      </div>

      {/* Floating cart bar */}
      {cartCount > 0 && (
        <div style={{
          position: 'absolute', left: 14, right: 14,
          bottom: BOT_INSET + 12,
          background: wsT.ink, color: wsT.bg,
          borderRadius: 16, padding: '14px 18px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          boxShadow: '0 12px 30px rgba(0,0,0,0.18)',
          cursor: 'pointer',
        }} onClick={onOpenCart}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 26, height: 26, borderRadius: 999,
              background: wsT.accent, color: wsT.accentInk,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: wsFont, fontSize: 13, fontWeight: 600,
            }}>{cartCount}</div>
            <span style={{ fontFamily: wsFont, fontSize: 15, fontWeight: 500, letterSpacing: '-0.01em' }}>
              View basket
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ color: wsT.bg }}><Money value={cartTotal} weight={500} /></span>
            <span style={{ opacity: 0.6, display: 'flex' }}>{Icon.chevR}</span>
          </div>
        </div>
      )}
    </div>
  );
}

// Mode toggle (Pickup / Delivery)
function ModeToggle({ mode, setMode }) {
  const opts = [
    { id: 'pickup',   label: 'Pickup',   sub: 'Ready ~12 min', icon: Icon.pin  },
    { id: 'delivery', label: 'Delivery', sub: '25–35 min',     icon: Icon.bike },
  ];
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6,
      padding: 4, background: wsT.surface, borderRadius: 14,
      border: `1px solid ${wsT.line}`,
    }}>
      {opts.map(o => {
        const active = mode === o.id;
        return (
          <button key={o.id} onClick={() => setMode(o.id)} style={{
            padding: '10px 14px', borderRadius: 11,
            background: active ? wsT.bg : 'transparent',
            border: 'none', cursor: 'pointer',
            boxShadow: active ? '0 1px 3px rgba(0,0,0,0.06)' : 'none',
            display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 2,
            color: active ? wsT.ink : wsT.inkSoft,
            transition: 'all 0.18s ease',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ display: 'flex' }}>{o.icon}</span>
              <span style={{ fontFamily: wsFont, fontSize: 14, fontWeight: 500, letterSpacing: '-0.01em' }}>{o.label}</span>
            </div>
            <span style={{ fontFamily: wsFont, fontSize: 11, color: wsT.inkMuted, letterSpacing: '-0.005em' }}>{o.sub}</span>
          </button>
        );
      })}
    </div>
  );
}

function MenuRow({ item, onClick, compact }) {
  return (
    <button onClick={onClick} style={{
      width: '100%', textAlign: 'left',
      padding: compact ? '12px 14px' : '16px',
      borderRadius: 14,
      background: wsT.surface, border: `1px solid ${wsT.line}`,
      cursor: 'pointer', display: 'flex',
      alignItems: 'center', gap: 14,
      transition: 'all 0.12s ease',
      fontFamily: wsFont,
    }}
    onMouseEnter={e => e.currentTarget.style.borderColor = wsT.inkMuted}
    onMouseLeave={e => e.currentTarget.style.borderColor = wsT.line}>
      <ItemGlyph cat={item.cat} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
          <span style={{ fontSize: 15, fontWeight: 500, color: wsT.ink, letterSpacing: '-0.015em' }}>
            {item.name}
          </span>
          {item.bestseller && (
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 3,
              padding: '2px 7px', borderRadius: 999,
              background: wsT.accentSoft, color: wsT.accent,
              fontSize: 10, fontWeight: 500, letterSpacing: '0.02em',
              textTransform: 'uppercase',
            }}>{Icon.spark} Top</span>
          )}
        </div>
        <div style={{
          fontSize: 13, color: wsT.inkMuted, letterSpacing: '-0.005em',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>{item.desc}</div>
      </div>
      <div style={{ flexShrink: 0, color: wsT.ink }}>
        <Money value={item.price} size={14}/>
      </div>
    </button>
  );
}

// Tiny SVG glyph per category
function ItemGlyph({ cat }) {
  const stroke = wsT.inkSoft;
  const map = {
    Wings:  <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M4 18c2-6 7-9 12-10 1 3-1 8-5 11-3 2-6 1-7-1z" stroke={stroke} strokeWidth="1.4" strokeLinejoin="round"/><path d="M9 16l-3 3" stroke={stroke} strokeWidth="1.4" strokeLinecap="round"/></svg>,
    Buns:   <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M3 12a9 4 0 0118 0" stroke={stroke} strokeWidth="1.4"/><path d="M3 13h18M5 16h14M7 19h10" stroke={stroke} strokeWidth="1.4" strokeLinecap="round"/></svg>,
    Sides:  <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M7 9h10l-1 12H8L7 9z" stroke={stroke} strokeWidth="1.4" strokeLinejoin="round"/><path d="M10 9V4M13 9V6M16 9V5" stroke={stroke} strokeWidth="1.4" strokeLinecap="round"/></svg>,
    Drinks: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M7 4h10l-1 17H8L7 4z" stroke={stroke} strokeWidth="1.4" strokeLinejoin="round"/><path d="M7.5 9h9" stroke={stroke} strokeWidth="1.4"/></svg>,
  };
  return (
    <div style={{
      width: 44, height: 44, borderRadius: 11,
      background: wsT.surface2, display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}>{map[cat]}</div>
  );
}

// Logo mark — a tiny "shed" with a chicken silhouette
function Logo({ size = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M3 11l9-7 9 7v9a1 1 0 01-1 1H4a1 1 0 01-1-1v-9z" stroke={wsT.ink} strokeWidth="1.5" strokeLinejoin="round"/>
      <path d="M9 16c0-2 1.3-3.3 3-3.3s3 1 3 3h.5c.5 0 .5.7 0 .8L14 17c-.3 1-1.2 1.5-2 1.5s-1.7-.5-2-1.5l-.5-.2c-.5-.1-.5-.8 0-.8z" fill={wsT.ink}/>
      <circle cx="14" cy="14.4" r="0.5" fill={wsT.bg}/>
    </svg>
  );
}

Object.assign(window, { MenuScreen, Logo });
