// Wingshed menu data
const MENU = [
  { id: 'classic-6',   cat: 'Wings',  name: 'Classic Wings',     desc: '6 wings, dredged & double-fried',         price: 9.50,  bestseller: true },
  { id: 'classic-12',  cat: 'Wings',  name: 'Classic Wings',     desc: '12 wings — feeds two, just about',        price: 17.00 },
  { id: 'boneless',    cat: 'Wings',  name: 'Boneless Bites',    desc: 'Tender breast, crispy crumb',             price: 8.50 },
  { id: 'tendies',     cat: 'Wings',  name: 'Tenders',           desc: '4 hand-breaded tenders',                  price: 9.00 },
  { id: 'shed-burger', cat: 'Buns',   name: 'The Shed Burger',   desc: 'Buttermilk thigh, slaw, pickles, brioche',price: 11.50, bestseller: true },
  { id: 'hot-burger',  cat: 'Buns',   name: 'Hot Honey Burger',  desc: 'Spiced thigh, hot honey, blue cheese',    price: 12.00 },
  { id: 'wrap',        cat: 'Buns',   name: 'Crispy Wrap',       desc: 'Tenders, lettuce, ranch, soft tortilla',  price: 9.50 },
  { id: 'fries',       cat: 'Sides',  name: 'Shed Fries',        desc: 'Skin-on, rosemary salt',                  price: 4.00 },
  { id: 'loaded',      cat: 'Sides',  name: 'Loaded Fries',      desc: 'Cheese sauce, scallion, crispy bits',     price: 6.50 },
  { id: 'slaw',        cat: 'Sides',  name: 'House Slaw',        desc: 'Buttermilk, dill, black pepper',          price: 3.50 },
  { id: 'cola',        cat: 'Drinks', name: 'Cola',              desc: 'Mexican Coke, 355ml',                     price: 3.00 },
  { id: 'lemonade',    cat: 'Drinks', name: 'Cloudy Lemonade',   desc: 'Pressed in-house, not too sweet',         price: 3.50 },
  { id: 'beer',        cat: 'Drinks', name: 'Lager',             desc: 'Local pils, 330ml can',                   price: 5.00 },
];

const CATEGORIES = ['All', 'Wings', 'Buns', 'Sides', 'Drinks'];

const SAUCES = [
  { id: 'shed',     name: 'Shed Sauce',      heat: 1, desc: 'House blend, smoky' },
  { id: 'hot-honey',name: 'Hot Honey',       heat: 2, desc: 'Sticky, sweet, warm' },
  { id: 'buffalo',  name: 'Classic Buffalo', heat: 2, desc: 'Vinegar-forward' },
  { id: 'korean',   name: 'Gochujang Glaze', heat: 3, desc: 'Fermented chili, garlic' },
  { id: 'inferno',  name: 'Inferno',         heat: 4, desc: 'Carolina reaper. Sign waiver.' },
  { id: 'plain',    name: 'No sauce',        heat: 0, desc: 'Just salt' },
];

const DIPS = [
  { id: 'ranch',  name: 'Buttermilk Ranch', price: 0.80 },
  { id: 'blue',   name: 'Blue Cheese',      price: 0.80 },
  { id: 'garlic', name: 'Garlic Aioli',     price: 0.80 },
  { id: 'bbq',    name: 'Smoked BBQ',       price: 0.80 },
];

const PAST_ORDERS = [
  { id: 'WS-1042', when: 'Today, 12:14',     items: 3, total: 18.50, status: 'Ready for pickup', live: true },
  { id: 'WS-0987', when: 'Yesterday, 19:42', items: 5, total: 34.00, status: 'Completed' },
  { id: 'WS-0921', when: 'Apr 28, 13:07',    items: 2, total: 12.50, status: 'Completed' },
  { id: 'WS-0844', when: 'Apr 22, 20:11',    items: 4, total: 27.00, status: 'Completed' },
];

Object.assign(window, { MENU, CATEGORIES, SAUCES, DIPS, PAST_ORDERS });
