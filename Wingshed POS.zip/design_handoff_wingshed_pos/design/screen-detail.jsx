// Wingshed — Item detail (modifiers: sauce, spice, dips, qty, notes)
const { useState: useStateD } = React;

function ItemDetailScreen({ item, onClose, onAdd }) {
  const wingsItem = item.cat === 'Wings';
  const [sauce, setSauce] = useStateD(wingsItem ? 'shed' : null);
  const [dips, setDips] = useStateD([]);
  const [qty, setQty] = useStateD(1);
  const [notes, setNotes] = useStateD('');

  const sauceObj = SAUCES.find(s => s.id === sauce);
  const dipsTotal = dips.length * 0.80;
  const lineTotal = (item.price + dipsTotal) * qty;

  const toggleDip = id => setDips(d => d.includes(id) ? d.filter(x => x !== id) : [...d, id]);

  const submit = () => {
    onAdd({
      itemId: item.id, name: item.name, qty,
      mods: [
        sauceObj && { label: 'Sauce', value: sauceObj.name },
        dips.length && { label: 'Dips', value: dips.map(id => DIPS.find(d => d.id === id).name).join(', ') },
        notes && { label: 'Notes', value: notes },
      ].filter(Boolean),
      unitPrice: item.price + dipsTotal,
      lineTotal,
    });
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: wsT.bg }}>
      {/* Top bar */}
      <div style={{
        position: 'absolute', top: TOP_INSET - 12, left: 14, right: 14,
        display: 'flex', justifyContent: 'space-between', zIndex: 5,
      }}>
        <button onClick={onClose} style={iconBtn}>{Icon.back}</button>
      </div>

      {/* Hero panel */}
      <div style={{
        paddingTop: TOP_INSET + 30, padding: `${TOP_INSET + 30}px 24px 26px`,
        background: wsT.surface2,
        borderBottom: `1px solid ${wsT.line}`,
      }}>
        <div style={{
          fontFamily: wsFont, fontSize: 11, fontWeight: 500,
          letterSpacing: '0.08em', textTransform: 'uppercase',
          color: wsT.inkMuted, marginBottom: 10,
        }}>{item.cat}</div>
        <h1 style={{
          fontFamily: wsFont, fontSize: 30, fontWeight: 600,
          letterSpacing: '-0.035em', lineHeight: 1.05,
          margin: 0, color: wsT.ink,
        }}>{item.name}</h1>
        <p style={{
          fontFamily: wsFont, fontSize: 15, color: wsT.inkSoft,
          letterSpacing: '-0.01em', lineHeight: 1.45,
          margin: '8px 0 14px',
        }}>{item.desc}</p>
        <div style={{ color: wsT.ink }}>
          <Money value={item.price} weight={500} size={18}/>
        </div>
      </div>

      {/* Modifiers — scrollable */}
      <div style={{ flex: 1, overflow: 'auto', padding: '8px 0 140px' }}>

        {/* Sauce — only on wings/tenders/boneless */}
        {(item.cat === 'Wings') && (
          <Section title="Pick a sauce" required>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {SAUCES.map(s => (
                <label key={s.id} style={radioRow(sauce === s.id)}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 2 }}>
                      <span style={{ fontFamily: wsFont, fontSize: 15, fontWeight: 500, color: wsT.ink, letterSpacing: '-0.015em' }}>{s.name}</span>
                      {s.heat > 0 && <HeatDots n={s.heat}/>}
                    </div>
                    <div style={{ fontFamily: wsFont, fontSize: 13, color: wsT.inkMuted, letterSpacing: '-0.005em' }}>{s.desc}</div>
                  </div>
                  <RadioDot active={sauce === s.id} />
                  <input type="radio" name="sauce" checked={sauce === s.id} onChange={() => setSauce(s.id)} style={{ display: 'none' }}/>
                </label>
              ))}
            </div>
          </Section>
        )}

        {/* Dips — for everything */}
        <Section title="Add dips" hint="80p each">
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {DIPS.map(d => (
              <label key={d.id} style={radioRow(dips.includes(d.id))} onClick={() => toggleDip(d.id)}>
                <span style={{ flex: 1, fontFamily: wsFont, fontSize: 15, fontWeight: 500, color: wsT.ink, letterSpacing: '-0.015em' }}>{d.name}</span>
                <span style={{ marginRight: 12, color: wsT.inkMuted }}>
                  <Money value={d.price} weight={400} size={13}/>
                </span>
                <CheckBox active={dips.includes(d.id)} />
              </label>
            ))}
          </div>
        </Section>

        {/* Notes */}
        <Section title="Anything else?">
          <div style={{ padding: '0 20px' }}>
            <textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Allergies, prep notes…"
              style={{
                width: '100%', minHeight: 64, resize: 'none',
                padding: '12px 14px', borderRadius: 12,
                border: `1px solid ${wsT.line}`, background: wsT.surface,
                fontFamily: wsFont, fontSize: 14, color: wsT.ink,
                letterSpacing: '-0.005em', outline: 'none',
                boxSizing: 'border-box',
              }}
            />
          </div>
        </Section>
      </div>

      {/* Bottom dock — qty + add */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        background: wsT.bg, borderTop: `1px solid ${wsT.line}`,
        padding: `16px 18px ${BOT_INSET + 14}px`,
        display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <Stepper value={qty} onChange={setQty} min={1}/>
        <button onClick={submit} style={{
          flex: 1, height: 52, borderRadius: 14,
          background: wsT.ink, color: wsT.bg, border: 'none',
          fontFamily: wsFont, fontSize: 15, fontWeight: 500,
          letterSpacing: '-0.005em', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 20px',
        }}>
          <span>Add to basket</span>
          <span style={{ opacity: 0.85 }}><Money value={lineTotal} weight={500} size={15}/></span>
        </button>
      </div>
    </div>
  );
}

const iconBtn = {
  width: 38, height: 38, borderRadius: 999,
  border: `1px solid ${wsT.line}`, background: wsT.bg,
  color: wsT.ink, cursor: 'pointer',
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  boxShadow: '0 1px 2px rgba(0,0,0,0.04)',
};

const radioRow = active => ({
  display: 'flex', alignItems: 'center',
  padding: '14px 20px',
  borderTop: `1px solid ${wsT.line}`,
  cursor: 'pointer',
  background: active ? wsT.surface : 'transparent',
  transition: 'background 0.15s ease',
});

function Section({ title, hint, required, children }) {
  return (
    <div style={{ marginTop: 22 }}>
      <div style={{
        padding: '0 20px 10px', display: 'flex',
        alignItems: 'baseline', justifyContent: 'space-between',
      }}>
        <div>
          <span style={{ fontFamily: wsFont, fontSize: 15, fontWeight: 600, color: wsT.ink, letterSpacing: '-0.02em' }}>{title}</span>
          {required && <span style={{
            marginLeft: 8, fontFamily: wsFont, fontSize: 10, fontWeight: 500,
            letterSpacing: '0.06em', textTransform: 'uppercase',
            color: wsT.accent,
          }}>Required</span>}
        </div>
        {hint && <span style={{ fontFamily: wsFont, fontSize: 12, color: wsT.inkMuted }}>{hint}</span>}
      </div>
      <div style={{ borderBottom: `1px solid ${wsT.line}` }}>{children}</div>
    </div>
  );
}

function RadioDot({ active }) {
  return (
    <div style={{
      width: 22, height: 22, borderRadius: 999,
      border: `1.5px solid ${active ? wsT.ink : wsT.line}`,
      background: active ? wsT.ink : 'transparent',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}>
      {active && <div style={{ width: 8, height: 8, borderRadius: 99, background: wsT.bg }}/>}
    </div>
  );
}

function CheckBox({ active }) {
  return (
    <div style={{
      width: 22, height: 22, borderRadius: 6,
      border: `1.5px solid ${active ? wsT.ink : wsT.line}`,
      background: active ? wsT.ink : 'transparent',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0, color: wsT.bg,
    }}>
      {active && <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M5 12.5l4.5 4.5L19 7.5" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>}
    </div>
  );
}

Object.assign(window, { ItemDetailScreen });
