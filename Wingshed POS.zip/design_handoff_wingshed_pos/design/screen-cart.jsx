// Wingshed — Cart, Checkout, Confirmation, Orders
const { useState: useStateC } = React;

// ═══ Cart ════════════════════════════════════════════════════════════════
function CartScreen({ cart, setCart, mode, onBack, onCheckout }) {
  const subtotal = cart.reduce((s, l) => s + l.lineTotal, 0);
  const delivery = mode === 'delivery' ? 2.50 : 0;
  const total = subtotal + delivery;

  const setQty = (idx, q) => {
    setCart(c => {
      const next = [...c];
      if (q <= 0) next.splice(idx, 1);
      else {
        next[idx] = { ...next[idx], qty: q, lineTotal: next[idx].unitPrice * q };
      }
      return next;
    });
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: wsT.bg }}>
      <div style={{
        paddingTop: TOP_INSET, padding: `${TOP_INSET}px 20px 14px`,
        display: 'flex', alignItems: 'center', gap: 14,
        borderBottom: `1px solid ${wsT.line}`,
      }}>
        <button onClick={onBack} style={{
          width: 36, height: 36, borderRadius: 999,
          border: `1px solid ${wsT.line}`, background: 'transparent',
          color: wsT.ink, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.back}</button>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: wsFont, fontSize: 19, fontWeight: 600, color: wsT.ink, letterSpacing: '-0.025em' }}>Your basket</div>
          <div style={{ fontFamily: wsFont, fontSize: 12, color: wsT.inkMuted, letterSpacing: '-0.005em', marginTop: 1 }}>
            {mode === 'delivery' ? 'Delivery · 25–35 min' : 'Pickup · ~12 min'}
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '8px 0 24px' }}>
        {cart.length === 0 && (
          <div style={{
            padding: '80px 30px', textAlign: 'center',
            fontFamily: wsFont, color: wsT.inkMuted,
          }}>
            <div style={{ fontSize: 16, fontWeight: 500, color: wsT.inkSoft, marginBottom: 6, letterSpacing: '-0.01em' }}>Empty basket</div>
            <div style={{ fontSize: 13 }}>Add something from the menu.</div>
          </div>
        )}

        {cart.map((line, i) => (
          <div key={i} style={{
            padding: '16px 20px', display: 'flex', gap: 14,
            borderBottom: `1px solid ${wsT.line}`,
          }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 12 }}>
                <span style={{ fontFamily: wsFont, fontSize: 15, fontWeight: 500, color: wsT.ink, letterSpacing: '-0.015em' }}>{line.name}</span>
                <span style={{ color: wsT.ink }}><Money value={line.lineTotal} weight={500} size={14}/></span>
              </div>
              {line.mods.map((m, mi) => (
                <div key={mi} style={{
                  fontFamily: wsFont, fontSize: 12, color: wsT.inkMuted,
                  letterSpacing: '-0.005em', marginTop: 3,
                }}>
                  <span style={{ opacity: 0.6 }}>{m.label}: </span>{m.value}
                </div>
              ))}
              <div style={{ marginTop: 10 }}>
                <Stepper value={line.qty} onChange={q => setQty(i, q)} min={0} compact/>
              </div>
            </div>
          </div>
        ))}

        {cart.length > 0 && (
          <div style={{ padding: '20px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <SummaryRow label="Subtotal" value={subtotal}/>
              {mode === 'delivery' && <SummaryRow label="Delivery" value={delivery}/>}
              <div style={{ borderTop: `1px solid ${wsT.line}`, marginTop: 6, paddingTop: 12 }}>
                <SummaryRow label="Total" value={total} bold/>
              </div>
            </div>

            {/* Promo */}
            <div style={{
              marginTop: 18, padding: '14px 14px', borderRadius: 12,
              border: `1px dashed ${wsT.line}`,
              display: 'flex', alignItems: 'center', gap: 10,
              fontFamily: wsFont, fontSize: 13, color: wsT.inkSoft, letterSpacing: '-0.005em',
            }}>
              <span style={{ color: wsT.accent, display: 'flex' }}>{Icon.spark}</span>
              Add a promo code at checkout
            </div>
          </div>
        )}
      </div>

      {cart.length > 0 && (
        <div style={{
          padding: `14px 18px ${BOT_INSET + 14}px`,
          borderTop: `1px solid ${wsT.line}`,
          background: wsT.bg,
        }}>
          <button onClick={onCheckout} style={{
            width: '100%', height: 54, borderRadius: 14,
            background: wsT.ink, color: wsT.bg, border: 'none',
            fontFamily: wsFont, fontSize: 15, fontWeight: 500,
            letterSpacing: '-0.005em', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '0 22px',
          }}>
            <span>Checkout</span>
            <span><Money value={total} weight={500} size={15}/></span>
          </button>
        </div>
      )}
    </div>
  );
}

function SummaryRow({ label, value, bold }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between',
      fontFamily: wsFont, fontSize: bold ? 15 : 14,
      color: bold ? wsT.ink : wsT.inkSoft,
      fontWeight: bold ? 500 : 400, letterSpacing: '-0.005em',
    }}>
      <span>{label}</span>
      <span style={{ color: wsT.ink }}><Money value={value} weight={bold ? 500 : 400} size={bold ? 15 : 14}/></span>
    </div>
  );
}

// ═══ Checkout ════════════════════════════════════════════════════════════
function CheckoutScreen({ cart, mode, onBack, onPay }) {
  const [payment, setPayment] = useStateC('apple');
  const [name, setName] = useStateC('Sam');
  const subtotal = cart.reduce((s, l) => s + l.lineTotal, 0);
  const delivery = mode === 'delivery' ? 2.50 : 0;
  const total = subtotal + delivery;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: wsT.bg }}>
      <div style={{
        paddingTop: TOP_INSET, padding: `${TOP_INSET}px 20px 14px`,
        display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <button onClick={onBack} style={{
          width: 36, height: 36, borderRadius: 999,
          border: `1px solid ${wsT.line}`, background: 'transparent',
          color: wsT.ink, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.back}</button>
        <div style={{ fontFamily: wsFont, fontSize: 19, fontWeight: 600, color: wsT.ink, letterSpacing: '-0.025em' }}>Checkout</div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '8px 0 140px' }}>

        {/* Mode summary */}
        <div style={{ padding: '14px 20px' }}>
          <div style={{
            padding: '14px 16px', borderRadius: 14,
            border: `1px solid ${wsT.line}`, background: wsT.surface,
            display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              background: wsT.bg, border: `1px solid ${wsT.line}`,
              color: wsT.ink, display: 'flex',
              alignItems: 'center', justifyContent: 'center',
            }}>{mode === 'delivery' ? Icon.bike : Icon.pin}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: wsFont, fontSize: 14, fontWeight: 500, color: wsT.ink, letterSpacing: '-0.01em' }}>
                {mode === 'delivery' ? 'Delivery' : 'Pickup'}
              </div>
              <div style={{ fontFamily: wsFont, fontSize: 12, color: wsT.inkMuted, marginTop: 1 }}>
                {mode === 'delivery' ? '12 Hackney Rd · 25–35 min' : '108 Mare St · ready in ~12 min'}
              </div>
            </div>
            <span style={{ color: wsT.inkMuted }}>{Icon.chevR}</span>
          </div>
        </div>

        {/* Name field */}
        <CheckoutSection title="Order name">
          <input
            value={name} onChange={e => setName(e.target.value)}
            style={{
              width: '100%', padding: '14px 16px', borderRadius: 12,
              border: `1px solid ${wsT.line}`, background: wsT.surface,
              fontFamily: wsFont, fontSize: 15, color: wsT.ink,
              letterSpacing: '-0.01em', outline: 'none', boxSizing: 'border-box',
            }}
          />
        </CheckoutSection>

        {/* Payment methods */}
        <CheckoutSection title="Payment">
          <div style={{
            display: 'flex', flexDirection: 'column',
            border: `1px solid ${wsT.line}`, borderRadius: 14,
            overflow: 'hidden', background: wsT.surface,
          }}>
            {[
              { id: 'apple', label: 'Apple Pay',     sub: 'Touch to confirm' },
              { id: 'card',  label: 'Visa · 4242',   sub: 'Saved card' },
              { id: 'cash',  label: 'Cash on pickup', sub: 'Pay at counter' },
            ].map((p, i, arr) => (
              <label key={p.id} onClick={() => setPayment(p.id)} style={{
                padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 14,
                borderBottom: i < arr.length - 1 ? `1px solid ${wsT.line}` : 'none',
                cursor: 'pointer',
                background: payment === p.id ? wsT.surface2 : 'transparent',
              }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: wsFont, fontSize: 14, fontWeight: 500, color: wsT.ink, letterSpacing: '-0.01em' }}>{p.label}</div>
                  <div style={{ fontFamily: wsFont, fontSize: 12, color: wsT.inkMuted, marginTop: 1 }}>{p.sub}</div>
                </div>
                <RadioDot active={payment === p.id} />
              </label>
            ))}
          </div>
        </CheckoutSection>

        {/* Tip */}
        <CheckoutSection title="Tip the kitchen">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8 }}>
            {['£0', '£1', '£2', '£3'].map(t => (
              <button key={t} style={{
                padding: '12px 0', borderRadius: 12,
                border: `1px solid ${t === '£1' ? wsT.ink : wsT.line}`,
                background: t === '£1' ? wsT.ink : 'transparent',
                color: t === '£1' ? wsT.bg : wsT.ink,
                fontFamily: wsFont, fontSize: 14, fontWeight: 500,
                letterSpacing: '-0.005em', cursor: 'pointer',
              }}>{t}</button>
            ))}
          </div>
        </CheckoutSection>

        {/* Totals */}
        <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <SummaryRow label="Subtotal" value={subtotal}/>
          {mode === 'delivery' && <SummaryRow label="Delivery" value={delivery}/>}
          <SummaryRow label="Tip" value={1}/>
          <div style={{ borderTop: `1px solid ${wsT.line}`, marginTop: 6, paddingTop: 12 }}>
            <SummaryRow label="Total" value={total + 1} bold/>
          </div>
        </div>
      </div>

      {/* Pay dock */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        padding: `14px 18px ${BOT_INSET + 14}px`,
        background: wsT.bg, borderTop: `1px solid ${wsT.line}`,
      }}>
        <button onClick={onPay} style={{
          width: '100%', height: 54, borderRadius: 14,
          background: wsT.ink, color: wsT.bg, border: 'none',
          fontFamily: wsFont, fontSize: 15, fontWeight: 500,
          letterSpacing: '-0.005em', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
        }}>
          {payment === 'apple' ? (
            <>
              <svg width="18" height="20" viewBox="0 0 18 20" fill="currentColor"><path d="M14.5 6.7c-.1 0-2.5.5-2.5 3.2 0 3.2 2.8 4.3 2.9 4.3 0 0-.4 1.5-1.4 3-.9 1.3-1.8 2.6-3.2 2.6-1.4 0-1.7-.8-3.3-.8-1.5 0-2.1.8-3.4.8-1.3 0-2.2-1.2-3.2-2.7-1-1.7-1.9-4.3-1.9-6.8 0-4 2.6-6.1 5.2-6.1 1.4 0 2.5.9 3.4.9.8 0 2.1-1 3.7-1 .6 0 2.7.1 4.1 2zM10.7 3.3C11.4 2.5 12 1.4 12 .3c0-.1 0-.3 0-.3-1.1.1-2.3.7-3 1.6-.6.7-1.2 1.8-1.2 2.9 0 .2 0 .3.1.4 0 0 .1 0 .2 0 1 0 2.2-.6 2.6-1.6z"/></svg>
              <span>Pay £{(total + 1).toFixed(2)}</span>
            </>
          ) : (
            <span>Place order · £{(total + 1).toFixed(2)}</span>
          )}
        </button>
      </div>
    </div>
  );
}

function CheckoutSection({ title, children }) {
  return (
    <div style={{ padding: '14px 20px 6px' }}>
      <div style={{
        fontFamily: wsFont, fontSize: 11, fontWeight: 500,
        letterSpacing: '0.08em', textTransform: 'uppercase',
        color: wsT.inkMuted, marginBottom: 10,
      }}>{title}</div>
      {children}
    </div>
  );
}

// ═══ Confirmation ════════════════════════════════════════════════════════
function ConfirmScreen({ orderCode, mode, total, onBackToMenu, onTrack }) {
  const [tick, setTick] = useStateC(false);
  React.useEffect(() => {
    const t = setTimeout(() => setTick(true), 200);
    return () => clearTimeout(t);
  }, []);

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', height: '100%',
      background: wsT.bg, paddingTop: TOP_INSET, paddingBottom: BOT_INSET,
      position: 'relative',
    }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 30px' }}>
        <div style={{
          width: 84, height: 84, borderRadius: 999,
          background: wsT.accent, color: wsT.accentInk,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginBottom: 26,
          transform: tick ? 'scale(1)' : 'scale(0.6)',
          opacity: tick ? 1 : 0,
          transition: 'all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)',
        }}>
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
            <path d="M5 12.5l4.5 4.5L19 7.5" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <h1 style={{
          fontFamily: wsFont, fontSize: 28, fontWeight: 600,
          letterSpacing: '-0.035em', textAlign: 'center', margin: 0,
          color: wsT.ink,
        }}>Order in!</h1>
        <p style={{
          fontFamily: wsFont, fontSize: 15, color: wsT.inkSoft,
          letterSpacing: '-0.01em', textAlign: 'center',
          margin: '10px 0 28px', lineHeight: 1.4,
        }}>
          {mode === 'delivery' ? "We've passed it to the kitchen. Rider's lining up." : "Pick up at 108 Mare St when you see your code."}
        </p>

        <div style={{
          padding: '22px 28px', borderRadius: 18,
          border: `1px solid ${wsT.line}`, background: wsT.surface,
          textAlign: 'center', minWidth: 220,
        }}>
          <div style={{
            fontFamily: wsFont, fontSize: 11, fontWeight: 500,
            letterSpacing: '0.08em', textTransform: 'uppercase',
            color: wsT.inkMuted, marginBottom: 6,
          }}>Order code</div>
          <div style={{
            fontFamily: wsMono, fontSize: 32, fontWeight: 500,
            letterSpacing: '-0.02em', color: wsT.ink,
          }}>{orderCode}</div>
          <div style={{
            marginTop: 14, paddingTop: 14, borderTop: `1px solid ${wsT.line}`,
            display: 'flex', justifyContent: 'space-between', gap: 20,
            fontFamily: wsFont, fontSize: 13,
          }}>
            <div style={{ textAlign: 'left' }}>
              <div style={{ color: wsT.inkMuted, fontSize: 11, letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: 2 }}>Ready</div>
              <div style={{ color: wsT.ink, fontWeight: 500 }}>~12 min</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ color: wsT.inkMuted, fontSize: 11, letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: 2 }}>Paid</div>
              <div style={{ color: wsT.ink, fontWeight: 500 }}><Money value={total} size={13}/></div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ padding: '0 18px 14px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button onClick={onTrack} style={{
          width: '100%', height: 52, borderRadius: 14,
          background: wsT.ink, color: wsT.bg, border: 'none',
          fontFamily: wsFont, fontSize: 15, fontWeight: 500,
          letterSpacing: '-0.005em', cursor: 'pointer',
        }}>Track order</button>
        <button onClick={onBackToMenu} style={{
          width: '100%', height: 48, borderRadius: 14,
          background: 'transparent', color: wsT.inkSoft, border: 'none',
          fontFamily: wsFont, fontSize: 14, fontWeight: 500,
          letterSpacing: '-0.005em', cursor: 'pointer',
        }}>Back to menu</button>
      </div>
    </div>
  );
}

// ═══ Orders / history ════════════════════════════════════════════════════
function OrdersScreen({ onBack, currentOrder }) {
  const live = currentOrder ? [currentOrder] : PAST_ORDERS.filter(o => o.live);
  const past = PAST_ORDERS.filter(o => !o.live);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: wsT.bg }}>
      <div style={{
        paddingTop: TOP_INSET, padding: `${TOP_INSET}px 20px 16px`,
        display: 'flex', alignItems: 'center', gap: 14,
        borderBottom: `1px solid ${wsT.line}`,
      }}>
        <button onClick={onBack} style={{
          width: 36, height: 36, borderRadius: 999,
          border: `1px solid ${wsT.line}`, background: 'transparent',
          color: wsT.ink, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{Icon.back}</button>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: wsFont, fontSize: 19, fontWeight: 600, color: wsT.ink, letterSpacing: '-0.025em' }}>Your orders</div>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '0 0 30px' }}>
        {live.length > 0 && (
          <>
            <SectionLabel>In progress</SectionLabel>
            {live.map(o => <OrderRow key={o.id} order={o} live/>)}
          </>
        )}
        <SectionLabel>Earlier</SectionLabel>
        {past.map(o => <OrderRow key={o.id} order={o}/>)}
      </div>
    </div>
  );
}

function SectionLabel({ children }) {
  return (
    <div style={{
      padding: '20px 20px 8px',
      fontFamily: wsFont, fontSize: 11, fontWeight: 500,
      letterSpacing: '0.08em', textTransform: 'uppercase',
      color: wsT.inkMuted,
    }}>{children}</div>
  );
}

function OrderRow({ order, live }) {
  return (
    <div style={{
      padding: '16px 20px',
      borderTop: `1px solid ${wsT.line}`,
      display: 'flex', alignItems: 'center', gap: 14,
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
          <span style={{ fontFamily: wsMono, fontSize: 14, fontWeight: 500, color: wsT.ink, letterSpacing: '-0.005em' }}>{order.id}</span>
          {live && (
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 5,
              padding: '2px 8px', borderRadius: 999,
              background: wsT.accentSoft, color: wsT.accent,
              fontFamily: wsFont, fontSize: 10, fontWeight: 500,
              letterSpacing: '0.04em', textTransform: 'uppercase',
            }}>
              <span style={{
                width: 6, height: 6, borderRadius: 99, background: wsT.accent,
                animation: 'wsPulse 1.4s ease-in-out infinite',
              }}/>
              {order.status}
            </span>
          )}
        </div>
        <div style={{ fontFamily: wsFont, fontSize: 13, color: wsT.inkMuted, letterSpacing: '-0.005em' }}>
          {order.when} · {order.items} item{order.items === 1 ? '' : 's'}
        </div>
      </div>
      <div style={{ color: wsT.ink, marginRight: 4 }}>
        <Money value={order.total} weight={500} size={14}/>
      </div>
      <span style={{ color: wsT.inkMuted, display: 'flex' }}>{Icon.chevR}</span>
    </div>
  );
}

Object.assign(window, { CartScreen, CheckoutScreen, ConfirmScreen, OrdersScreen });
