// Shared atoms + tokens for Wingshed
const { useState, useMemo, useEffect, useRef, useLayoutEffect, Fragment } = React;

const wsT = {
  bg:        'var(--ws-bg)',
  surface:   'var(--ws-surface)',
  surface2:  'var(--ws-surface-2)',
  ink:       'var(--ws-ink)',
  inkSoft:   'var(--ws-ink-soft)',
  inkMuted:  'var(--ws-ink-muted)',
  line:      'var(--ws-line)',
  accent:    'var(--ws-accent)',
  accentInk: 'var(--ws-accent-ink)',
  accentSoft:'var(--ws-accent-soft)',
  danger:    'var(--ws-danger)',
};
const wsFont = `'Geist', ui-sans-serif, system-ui, -apple-system, sans-serif`;
const wsMono = `'Geist Mono', ui-monospace, SFMono-Regular, monospace`;

const TOP_INSET = 54;
const BOT_INSET = 34;

// ─── Money ───────────────────────────────────────────────────────────────
function Money({ value, weight = 500, size }) {
  const [whole, frac] = Number(value).toFixed(2).split('.');
  return (
    <span style={{ fontFamily: wsMono, fontWeight: weight, fontSize: size, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.02em' }}>
      <span style={{ opacity: 0.5, fontSize: '0.78em', marginRight: 1 }}>£</span>{whole}<span style={{ opacity: 0.55 }}>.{frac}</span>
    </span>
  );
}

// ─── Chip / pill ─────────────────────────────────────────────────────────
function Chip({ active, children, onClick, dense, ghost }) {
  const bg = active ? wsT.ink : (ghost ? 'transparent' : wsT.surface);
  const fg = active ? wsT.bg : wsT.inkSoft;
  const bd = active ? wsT.ink : wsT.line;
  return (
    <button onClick={onClick} style={{
      padding: dense ? '6px 12px' : '8px 14px',
      borderRadius: 999,
      border: `1px solid ${bd}`,
      background: bg, color: fg,
      fontFamily: wsFont, fontSize: 13, fontWeight: 500,
      letterSpacing: '-0.01em', cursor: 'pointer',
      whiteSpace: 'nowrap', flexShrink: 0,
      transition: 'all 0.15s ease',
    }}>{children}</button>
  );
}

// ─── Heat indicator ──────────────────────────────────────────────────────
function HeatDots({ n }) {
  return (
    <div style={{ display: 'inline-flex', gap: 3, alignItems: 'center' }}>
      {[1,2,3,4].map(i => (
        <span key={i} style={{
          width: 5, height: 5, borderRadius: 99,
          background: i <= n ? wsT.accent : wsT.line,
        }}/>
      ))}
    </div>
  );
}

// ─── Stepper (qty +/-) ───────────────────────────────────────────────────
function Stepper({ value, onChange, min = 0, compact }) {
  const sz = compact ? 28 : 36;
  const btn = (sym, fn, disabled) => (
    <button onClick={fn} disabled={disabled} style={{
      width: sz, height: sz, borderRadius: 999,
      border: `1px solid ${wsT.line}`, background: 'transparent',
      color: disabled ? wsT.inkMuted : wsT.ink,
      fontFamily: wsFont, fontSize: compact ? 16 : 18, fontWeight: 400,
      cursor: disabled ? 'default' : 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      lineHeight: 1, padding: 0,
    }}>{sym}</button>
  );
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: compact ? 10 : 14 }}>
      {btn('−', () => onChange(Math.max(min, value - 1)), value <= min)}
      <span style={{
        fontFamily: wsMono, fontSize: compact ? 14 : 16, fontWeight: 500,
        minWidth: 14, textAlign: 'center', fontVariantNumeric: 'tabular-nums',
      }}>{value}</span>
      {btn('+', () => onChange(value + 1))}
    </div>
  );
}

// ─── Icon set (line, 24px stroke 1.5) ────────────────────────────────────
const Icon = {
  back: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  close: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>,
  bag: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M5 8h14l-1 12a2 2 0 01-2 2H8a2 2 0 01-2-2L5 8z" stroke="currentColor" strokeWidth="1.5"/><path d="M9 8V6a3 3 0 016 0v2" stroke="currentColor" strokeWidth="1.5"/></svg>,
  search: <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.6"/><path d="M16 16l4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>,
  receipt: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M6 3h12v18l-2-1.5-2 1.5-2-1.5-2 1.5-2-1.5L6 21V3z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/><path d="M9 8h6M9 12h6M9 16h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>,
  check: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M5 12.5l4.5 4.5L19 7.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  chevR: <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M9 6l6 6-6 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  pin: <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 21s7-7.5 7-12a7 7 0 10-14 0c0 4.5 7 12 7 12z" stroke="currentColor" strokeWidth="1.5"/><circle cx="12" cy="9" r="2.5" stroke="currentColor" strokeWidth="1.5"/></svg>,
  bike: <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="6" cy="17" r="3.5" stroke="currentColor" strokeWidth="1.5"/><circle cx="18" cy="17" r="3.5" stroke="currentColor" strokeWidth="1.5"/><path d="M6 17l5-9h5l2 9M11 8l-2-3H7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  spark: <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 3l1.8 5.7L19.5 10l-4.5 3.3L17 19l-5-3.5L7 19l2-5.7L4.5 10l5.7-1.3L12 3z" fill="currentColor"/></svg>,
};

// ─── Pressable button ────────────────────────────────────────────────────
function Btn({ children, onClick, primary, ghost, full, disabled, style }) {
  const base = {
    height: 52, borderRadius: 14, padding: '0 20px',
    fontFamily: wsFont, fontSize: 16, fontWeight: 500,
    letterSpacing: '-0.01em', cursor: disabled ? 'default' : 'pointer',
    border: 'none', display: 'inline-flex', alignItems: 'center',
    justifyContent: 'center', gap: 8,
    width: full ? '100%' : undefined,
    transition: 'transform 0.1s ease, opacity 0.15s',
    opacity: disabled ? 0.4 : 1,
  };
  const variants = primary
    ? { background: wsT.ink, color: wsT.bg }
    : ghost
    ? { background: 'transparent', color: wsT.ink, border: `1px solid ${wsT.line}` }
    : { background: wsT.surface, color: wsT.ink, border: `1px solid ${wsT.line}` };
  return (
    <button onClick={onClick} disabled={disabled} style={{ ...base, ...variants, ...style }}
      onMouseDown={e => !disabled && (e.currentTarget.style.transform = 'scale(0.98)')}
      onMouseUp={e => (e.currentTarget.style.transform = 'scale(1)')}
      onMouseLeave={e => (e.currentTarget.style.transform = 'scale(1)')}>
      {children}
    </button>
  );
}

Object.assign(window, { wsT, wsFont, wsMono, TOP_INSET, BOT_INSET, Money, Chip, HeatDots, Stepper, Icon, Btn });
