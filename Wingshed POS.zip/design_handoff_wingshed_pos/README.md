# Handoff: Wingshed POS — Customer Ordering App

Mobile-first ordering experience for **Wingshed**, a chicken-shop takeaway. Phone-sized, customer-facing self-order flow: menu → modifiers → basket → checkout → confirmation, plus order history.

---

## ⚠️ About the Design Files

The files in `design/` are **HTML/JSX design references** — interactive prototypes showing intended look and behavior. They are NOT production code to copy directly. Tasks for the developer:

1. **Recreate these designs in the target codebase** using its established framework, component library, and patterns.
2. If no codebase exists yet, the recommended stack is **Next.js (App Router) + TypeScript + Tailwind + shadcn/ui** — it maps cleanly to the prototype's structure.
3. Wire up real data via **Supabase** and real payments via **Stripe** (and/or Apple Pay / Google Pay through Stripe).

---

## Fidelity

**High-fidelity.** Final colors, typography, spacing, copy, and interactions. Recreate pixel-perfectly. All design tokens are listed below.

---

## Target platform

- **Phone, customer-facing.** Design width 390px (iPhone 12/13/14). Fluid down to 360px, up to ~480px. Above 480px, center the column.
- All hit targets ≥ 44px. Bottom-docked CTAs respect a 34px home-indicator inset.
- Light + dark themes; theme is a user toggle (defaults to system).

---

## Design tokens

All color tokens are defined as CSS custom properties on `:root` (light) and `[data-theme="dark"]` (dark). Use OKLCH so the accent is hue-tunable.

```css
:root {
  --ws-bg:          oklch(0.985 0.005 80);   /* page bg, warm off-white */
  --ws-surface:     oklch(0.972 0.006 80);   /* cards, inputs */
  --ws-surface-2:   oklch(0.955 0.008 80);   /* hero, subtle wash */
  --ws-ink:         oklch(0.18 0.012 60);    /* primary text, primary buttons */
  --ws-ink-soft:    oklch(0.32 0.01 60);     /* secondary text */
  --ws-ink-muted:   oklch(0.55 0.008 70);    /* tertiary text, captions */
  --ws-line:        oklch(0.9 0.006 80);     /* hairline borders, dividers */
  --ws-accent:      oklch(0.62 0.18 35);     /* terracotta — badges, hot chips, key moments */
  --ws-accent-ink:  oklch(0.99 0.005 80);    /* foreground on accent */
  --ws-accent-soft: oklch(0.95 0.04 35);     /* accent backgrounds */
  --ws-danger:      oklch(0.55 0.18 25);
}
[data-theme="dark"] {
  --ws-bg:          oklch(0.16 0.008 60);
  --ws-surface:     oklch(0.21 0.009 60);
  --ws-surface-2:   oklch(0.25 0.01 60);
  --ws-ink:         oklch(0.97 0.005 80);
  --ws-ink-soft:    oklch(0.85 0.006 70);
  --ws-ink-muted:   oklch(0.62 0.008 70);
  --ws-line:        oklch(0.3 0.01 60);
  --ws-accent:      oklch(0.72 0.16 38);
  --ws-accent-ink:  oklch(0.16 0.01 60);
  --ws-accent-soft: oklch(0.32 0.06 35);
}
```

### Typography
- **UI font:** Geist (300, 400, 500, 600, 700)
- **Numerals / order codes:** Geist Mono (400, 500)
- Load via Google Fonts. Use `font-variant-numeric: tabular-nums` on all monetary/numeric values.
- Type scale used:
  - Page title: 28px / 600 / -0.035em letter-spacing / 1.1 line-height
  - Hero title (item detail): 30px / 600 / -0.035em
  - Screen header: 19px / 600 / -0.025em
  - Body / item name: 15px / 500 / -0.015em
  - Helper / desc: 13px / 400 / -0.005em
  - Caption / meta: 12px / 400
  - Eyebrow (uppercase): 11px / 500 / 0.08em / uppercase
  - Button: 15–16px / 500
  - Money (mono): 14–18px / 500 / -0.02em / tabular-nums

### Spacing
4-based scale. Most-used: 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 28, 30, 32.
Screen edge padding: **20px**. Card padding: **14–16px**.

### Radii
- Pill / chip: 999
- Button: 14
- Card / input: 12–14
- Tile glyph: 11
- Section card: 14–18

### Shadows
- Floating cart bar: `0 12px 30px rgba(0,0,0,0.18)`
- Active mode toggle: `0 1px 3px rgba(0,0,0,0.06)`
- Subtle button: `0 1px 2px rgba(0,0,0,0.04)`

### Motion
- Theme/state transitions: 150ms ease
- Screen change: `wsFade` keyframe — `opacity 0 → 1, translateY(8px → 0)`, 250ms ease
- Confirmation tick: `cubic-bezier(0.34, 1.56, 0.64, 1)` 400ms scale 0.6 → 1
- Live status dot: `wsPulse` — `opacity 1 ↔ 0.4, scale 1 ↔ 0.85`, 1.4s ease-in-out infinite

---

## Screens

Six screens. Each lives at its own route. State (cart, mode, selected order) is shared via a global store (Zustand recommended) or React context.

### 01 — Menu (`/`)

**Purpose:** Browse the menu, switch between pickup/delivery, search, see active basket.

**Layout (top → bottom):**
1. Header bar (paddingTop = 54px to clear status bar): logo (24px) + "wingshed" wordmark (left) · 38px circular icon button → orders history (right)
2. **Mode toggle**: 2-column segmented control inside a 14px-radius surface, 4px inset padding. Active option gets `--ws-bg` background and a subtle shadow. Each option shows icon + label + sub-label (eta).
3. **Greeting**: "What's your damage tonight?" h1, 28px/600. Below it, 14px muted "Kitchen open · ~12 min wait".
4. **Search input**: 12px-radius surface, search glyph + input. Filters the list live by item name.
5. **Category chips (horizontal scroll):** All, Wings, Buns, Sides, Drinks. Active chip = filled `--ws-ink` with `--ws-bg` text.
6. **Item list (vertical):** Tappable rows, gap 8px (4px in compact density). Each row:
   - 44×44 category glyph tile (line icon on `--ws-surface-2`)
   - Item name (15/500) + "Top" pill if `bestseller` (accent-soft bg, accent text, sparkle icon)
   - Description (13/inkMuted, single-line ellipsis)
   - Price (Money component, 14px mono, right)
7. **Floating basket bar** (only when cart > 0): absolutely positioned bottom-left/right, ink-colored card. Item count chip (accent) + "View basket" + total + chevron. Tapping → `/cart`.

**Dark mode:** the entire palette swaps via `data-theme="dark"` on `<html>`.

### 02 — Item detail (`/item/[id]`)

**Purpose:** Configure an item with sauce, dips, notes; pick quantity; add to basket.

**Layout:**
1. Floating back button (38px circle, top-left, sits above hero).
2. **Hero panel** on `--ws-surface-2`: category eyebrow, item name (30/600), description, price.
3. **Modifier sections** (each: section title + optional "Required" badge + optional hint, then bordered rows):
   - **Pick a sauce** (Wings only, required): radio rows. Each shows sauce name + heat dots (0–4) + 13px desc. Right side: filled circle when active.
   - **Add dips** (multi-select, "80p each" hint): checkbox rows with price.
   - **Anything else?**: textarea (12px-radius `--ws-surface`, "Allergies, prep notes…").
4. **Bottom dock**: stepper (qty, min 1) + primary "Add to basket" button showing live `unitPrice * qty` total.

**State per item:** `sauce` (string|null), `dips` (string[]), `qty` (number), `notes` (string).

### 03 — Basket (`/cart`)

**Purpose:** Review and adjust line items, see totals, proceed to checkout.

**Layout:**
1. Header: back button + title "Your basket" + sub-line ("Pickup · ~12 min" or "Delivery · 25–35 min").
2. **Line items**: each shows name + line total (right), then modifier lines ("Sauce: Hot Honey", "Dips: Buttermilk Ranch") in 12px muted. Compact stepper underneath; setting qty to 0 removes the line.
3. **Summary**: Subtotal, Delivery (if delivery), Total (bold, top-bordered).
4. **Promo hint card** (dashed border): "Add a promo code at checkout".
5. **Bottom dock**: "Checkout" button with total.

**Empty state**: centered "Empty basket" + "Add something from the menu."

### 04 — Checkout (`/checkout`)

**Purpose:** Confirm fulfillment, pick payment, tip, pay.

**Sections:**
1. Mode summary card: icon + label + address/eta + chevron (tap to change).
2. Order name input (defaults to user name from auth).
3. Payment methods (radio list inside one bordered card):
   - Apple Pay — "Touch to confirm"
   - Visa · 4242 — "Saved card"
   - Cash on pickup — "Pay at counter"
4. Tip (4-button grid: £0, £1, £2, £3; £1 default).
5. Totals: Subtotal, Delivery, Tip, **Total**.
6. **Bottom dock**: ink button. If Apple Pay selected, show Apple logo + "Pay £X.XX". Otherwise "Place order · £X.XX".

### 05 — Confirmation (`/orders/[code]/confirmed`)

**Purpose:** Reassure user the order landed; show order code; route to tracking or back to menu.

**Layout (centered):**
1. 84px circle, accent-filled, animated check (scale 0.6 → 1, spring easing on mount).
2. "Order in!" h1 (28/600).
3. Sub-copy varies by mode:
   - Pickup: "Pick up at 108 Mare St when you see your code."
   - Delivery: "We've passed it to the kitchen. Rider's lining up."
4. **Order card**: "Order code" eyebrow → mono 32px code (e.g. `WS-1142`). Divider. Two columns: "Ready ~12 min" / "Paid £X.XX".
5. Bottom: ink "Track order" + ghost "Back to menu".

### 06 — Orders (`/orders`)

**Purpose:** Show in-progress + past orders.

**Sections:**
1. **In progress**: live order with pulsing accent dot + status pill ("In the fryer", "Ready for pickup").
2. **Earlier**: completed orders.

Each row: mono order id + when + item count + total + chevron. Tapping → order detail (out of scope for this initial cut, but the route should exist).

---

## Interactions & state

### Global state (Zustand recommended)
```ts
type Mode = 'pickup' | 'delivery';

interface CartLine {
  id: string;          // uuid for the line
  itemId: string;      // FK to menu_items
  name: string;
  qty: number;
  mods: { label: string; value: string }[];
  unitPrice: number;   // includes dip surcharges
  lineTotal: number;   // unitPrice * qty
}

interface AppStore {
  mode: Mode;
  cart: CartLine[];
  setMode(m: Mode): void;
  addLine(l: CartLine): void;
  setQty(idx: number, qty: number): void;
  clearCart(): void;
}
```

Persist `cart` and `mode` to `localStorage` so a refresh doesn't lose state.

### Navigation flows
- Menu → tap item → Detail → "Add to basket" → back to Menu (with floating bar visible)
- Menu → "View basket" → Cart → "Checkout" → Checkout → "Pay" → Confirmation → "Track order" → Orders
- Menu header (receipt icon) → Orders

### Form validation
- Sauce required on Wings items — disable "Add to basket" until selected.
- Order name required (default to auth user; can edit).
- Tip default = £1.
- Disable Pay button while payment intent is processing.

---

## 🗄️ Supabase integration

Recommended schema. Adjust column types to your conventions.

### Tables

```sql
-- Auth handled by Supabase Auth. Customer profile:
create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  display_name text,
  phone text,
  created_at timestamptz default now()
);

-- Catalogue
create table public.menu_categories (
  id text primary key,                -- 'wings', 'buns', 'sides', 'drinks'
  label text not null,
  position int not null
);

create table public.menu_items (
  id text primary key,                -- 'classic-6', 'shed-burger'
  category_id text not null references menu_categories(id),
  name text not null,
  description text,
  price_pence int not null,           -- store money as integer pence
  is_bestseller boolean default false,
  is_active boolean default true,
  position int default 0
);

create table public.sauces (
  id text primary key,
  name text not null,
  description text,
  heat int not null check (heat between 0 and 4)
);

create table public.dips (
  id text primary key,
  name text not null,
  price_pence int not null
);

-- Orders
create type order_status as enum ('pending', 'paid', 'in_kitchen', 'ready', 'completed', 'cancelled');
create type fulfillment_mode as enum ('pickup', 'delivery');

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                 -- 'WS-1142' (generate server-side)
  user_id uuid references auth.users,        -- nullable for guest checkout
  status order_status not null default 'pending',
  mode fulfillment_mode not null,
  subtotal_pence int not null,
  delivery_pence int default 0,
  tip_pence int default 0,
  total_pence int not null,
  customer_name text not null,
  delivery_address text,                     -- nullable when pickup
  payment_provider text,                     -- 'stripe', 'apple_pay', etc
  payment_intent_id text,                    -- Stripe PaymentIntent
  notes text,
  created_at timestamptz default now(),
  ready_at timestamptz
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  menu_item_id text not null references menu_items(id),
  qty int not null,
  unit_price_pence int not null,
  line_total_pence int not null,
  sauce_id text references sauces(id),
  dip_ids text[] default '{}',
  notes text
);

create index on public.orders (user_id, created_at desc);
create index on public.orders (status) where status in ('pending','paid','in_kitchen','ready');
```

### Row Level Security

```sql
alter table profiles      enable row level security;
alter table orders        enable row level security;
alter table order_items   enable row level security;

-- Profiles: user sees/edits their own
create policy "own profile" on profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);

-- Orders: user sees their own. Insert via server only (using service role key in Edge Function).
create policy "own orders" on orders
  for select using (auth.uid() = user_id);

create policy "own order items" on order_items
  for select using (
    exists (select 1 from orders o where o.id = order_id and o.user_id = auth.uid())
  );

-- Menu, sauces, dips are public-read
alter table menu_items enable row level security;
create policy "public read items" on menu_items for select using (is_active);
-- (mirror for menu_categories, sauces, dips)
```

### Realtime
Subscribe to `orders` filtered by `user_id` and the current order id to drive the order-tracking screen — show transitions as the kitchen flips status.

```ts
supabase
  .channel(`order:${orderId}`)
  .on('postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'orders', filter: `id=eq.${orderId}` },
      payload => updateOrderStatus(payload.new))
  .subscribe();
```

### Edge Functions to build
1. **`create-order`** — atomic. Validates cart against current menu prices (don't trust client totals!), creates `orders` row in `pending`, creates `order_items`, creates Stripe PaymentIntent, returns `{ orderId, code, clientSecret }`.
2. **`stripe-webhook`** — verifies signature, on `payment_intent.succeeded` flips order to `paid` and notifies the kitchen channel.
3. **`generate-order-code`** — assigns `WS-####` sequentially (or use a Postgres sequence + format).

### Environment variables
```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=     # server-side only
STRIPE_PUBLISHABLE_KEY=
STRIPE_SECRET_KEY=             # server-side only
STRIPE_WEBHOOK_SECRET=
```

---

## 💳 Payments integration

### Stripe (recommended primary)
- Use **Stripe Payment Intents** + **Payment Element** (handles cards, Apple Pay, Google Pay, Link in one component).
- Frontend:
  ```ts
  const stripe = await loadStripe(STRIPE_PUBLISHABLE_KEY);
  const elements = stripe.elements({ clientSecret });
  const paymentElement = elements.create('payment');
  paymentElement.mount('#payment-element');
  ```
- Server creates the PaymentIntent in the `create-order` Edge Function with `automatic_payment_methods: { enabled: true }`.
- Confirm with `stripe.confirmPayment({ elements, confirmParams: { return_url } })`.
- After redirect back, show the Confirmation screen and start the realtime subscription.

### Apple Pay / Google Pay
- Both supported automatically by Stripe Payment Element when domain is registered (Apple) and the site is HTTPS.
- The mock's "Apple Pay" tile should be the default when the device supports it (`window.ApplePaySession?.canMakePayments()`).

### Cash on pickup
- Skip Stripe; create the order directly in `paid` status with `payment_provider = 'cash'`. Kitchen still receives it; payment is collected at counter.

### Receipts
- Stripe sends email receipts when `receipt_email` is set on the PaymentIntent.
- Or send your own via Supabase Edge Function + Resend / Postmark on `payment_intent.succeeded`.

---

## File map (for implementer)

```
design_handoff_wingshed_pos/
├── README.md                          ← this file
└── design/
    ├── Wingshed POS.html              ← entry point — open in a browser to see the prototype
    ├── data.jsx                       ← MENU, CATEGORIES, SAUCES, DIPS, PAST_ORDERS — port to Supabase seed data
    ├── atoms.jsx                      ← shared tokens, Money, Chip, HeatDots, Stepper, Btn, Icon set
    ├── screen-menu.jsx                ← Menu screen, mode toggle, item rows, category glyphs, logo
    ├── screen-detail.jsx              ← Item detail, sauce/dip/notes modifiers
    ├── screen-cart.jsx                ← Cart, Checkout, Confirmation, Orders screens (one file, four exports)
    ├── ios-frame.jsx                  ← Device frame for the prototype only — DO NOT port; use real viewport
    └── tweaks-panel.jsx               ← In-prototype dev panel — DO NOT port
```

### What to port vs skip
| File | Port? | Notes |
|---|---|---|
| `data.jsx` | ✅ Use as seed | Convert prices to integer pence. Seed Supabase via SQL or a `seed.ts`. |
| `atoms.jsx` | ✅ Recreate as components | The token contract (`--ws-*` CSS vars), `<Money>`, `<Chip>`, `<HeatDots>`, `<Stepper>`, `<Btn>` should map directly to your design system. |
| `screen-*.jsx` | ✅ Recreate | Use as visual + behavioral spec. Replace inline style objects with Tailwind classes or CSS modules per your codebase. |
| `ios-frame.jsx` | ❌ Skip | Prototype-only chrome. Real app uses native viewport. |
| `tweaks-panel.jsx` | ❌ Skip | Prototype dev affordance. |
| `Wingshed POS.html` | 🔍 Reference only | The `<App>` block at the bottom shows the navigation graph and global state shape. |

---

## Copy reference (verbatim from prototype)

- Greeting: **"What's your damage tonight?"**
- Kitchen status: **"Kitchen open · ~12 min wait"**
- Search placeholder: **"Search the menu"**
- Mode subs: **"Ready ~12 min"** (pickup), **"25–35 min"** (delivery)
- Item-detail textarea: **"Allergies, prep notes…"**
- Sauce eyebrow: **"Required"**, dip hint: **"80p each"**
- Tip section: **"Tip the kitchen"**
- Confirm h1: **"Order in!"**
- Confirm sub (pickup): **"Pick up at 108 Mare St when you see your code."**
- Confirm sub (delivery): **"We've passed it to the kitchen. Rider's lining up."**
- Footer: **"Wingshed · est. 2021 · made in a hurry, eaten faster"**
- Inferno sauce desc: **"Carolina reaper. Sign waiver."** (keep this — it's funny and on-brand)

---

## Out of scope (future work)
- Kitchen-side queue / bumping view (paired companion app)
- Loyalty / sign-in flow beyond Supabase Auth basics
- Promo code redemption (UI hint exists; endpoint not specified)
- Order tracking map for delivery
- Manager / admin reporting

---

## Questions for the implementer to resolve
1. Are guest checkouts allowed, or sign-in required? (Schema supports nullable `user_id`.)
2. Delivery zones / address validation — postcode lookup provider?
3. SMS notifications when order ready — Twilio or kitchen-display only?
4. Refund flow + cancellation window — needs UI not in this cut.
